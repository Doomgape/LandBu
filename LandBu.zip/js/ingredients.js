$(function() {
  $('.burgers__menu-inside' + '.ingr').hover(function() { 
      $('.hidden-ingredients').fadeIn(); 
  }, function() { 
      $('.hidden-ingredients').fadeOut(); 
  });
  });
